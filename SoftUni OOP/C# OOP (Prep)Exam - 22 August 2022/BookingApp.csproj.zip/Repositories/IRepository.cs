﻿namespace BookingApp.Repositories
{
    public interface IRepository
    {
    }
}
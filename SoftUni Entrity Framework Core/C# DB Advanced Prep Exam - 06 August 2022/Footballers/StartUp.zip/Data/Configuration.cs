﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-U0UT8KF\SQLEXPRES\S;Database=FootballersExam;Trusted_Connection=True";
    }
}

﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-U0UT8KF\SQLEXPRESS;Database=ProductShop;Integrated Security=True";
    }
}

﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-U0UT8KF\SQLEXPRESS;Database=Theatre;Integrated Security=True;Encrypt=False";
    }
}

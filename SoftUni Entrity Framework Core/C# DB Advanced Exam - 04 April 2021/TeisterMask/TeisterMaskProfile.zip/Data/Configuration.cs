﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-U0UT8KF\SQLEXPRESS;Database=TeisterMaskExam;Integrated Security=True;Encrypt=False";
    }
}

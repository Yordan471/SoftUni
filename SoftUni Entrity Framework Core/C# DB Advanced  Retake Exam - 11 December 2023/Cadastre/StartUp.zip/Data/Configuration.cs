﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-U0UT8KF\SQLEXPRESS;Database=SoftUni;Trusted_Connection=True;TrustServerCertificate=True";
    }
}
